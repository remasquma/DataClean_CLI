import pandas as pd
from pathlib import Path
from typing import Optional


class UnsupportedFormatError(Exception):
    pass


def load_data(input_file: Path, encoding: Optional[str] = None) -> pd.DataFrame:
    if not input_file.exists():
        raise FileNotFoundError(f"Input file not found: {input_file}")

    suffix = input_file.suffix.lower()

    if suffix == ".csv":
        encodings_to_try = [encoding] if encoding else ["utf-8-sig", "utf-8", "latin-1"]
        last_err = None
        for enc in encodings_to_try:
            try:
                return pd.read_csv(input_file, encoding=enc)
            except (UnicodeDecodeError, LookupError) as e:
                last_err = e
                continue
        raise UnicodeDecodeError(f"Could not decode {input_file} with any known encoding") from last_err

    elif suffix == ".json":
        return pd.read_json(input_file, encoding=encoding or "utf-8")

    elif suffix in (".xls", ".xlsx"):
        return pd.read_excel(input_file)

    else:
        raise UnsupportedFormatError(f"Unsupported input format: {suffix}")


def save_data(df: pd.DataFrame, output_file: Path, output_format: str) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    fmt = output_format.lower()

    if fmt == "csv":
        df.to_csv(output_file, index=False, encoding="utf-8-sig")
    elif fmt == "json":
        df.to_json(output_file, orient="records", force_ascii=False, indent=2)
    elif fmt == "excel":
        df.to_excel(output_file, index=False)
    else:
        raise UnsupportedFormatError(f"Unsupported output format: {output_format}")


def drop_duplicate_rows(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates()


def drop_empty_rows_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.dropna(axis=0, how="all")
    df = df.dropna(axis=1, how="all")
    return df


def trim_whitespace(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].str.strip()
    return df


def standardize_dates(df: pd.DataFrame, columns: Optional[list] = None, fmt: str = "%Y-%m-%d") -> pd.DataFrame:
    target_cols = columns or df.select_dtypes(include="object").columns
    for col in target_cols:
        if col not in df.columns:
            continue
        try:
            parsed = pd.to_datetime(df[col], errors="coerce")
            if parsed.notna().mean() > 0.5:
                df[col] = parsed.dt.strftime(fmt)
        except Exception:
            continue
    return df


def clean_pipeline(
    df: pd.DataFrame,
    drop_duplicates: bool = False,
    drop_empty: bool = False,
    trim_whitespace_flag: bool = False,
    standardize_dates_flag: bool = False,
) -> pd.DataFrame:
    if drop_empty:
        df = drop_empty_rows_cols(df)
    if trim_whitespace_flag:
        df = trim_whitespace(df)
    if standardize_dates_flag:
        df = standardize_dates(df)
    if drop_duplicates:
        df = drop_duplicate_rows(df)
    return df