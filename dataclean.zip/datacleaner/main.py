import typer
from pathlib import Path
from typing import Optional

import core, profiling, recipes

app = typer.Typer(help="A local tool for cleaning and transforming data.")

SUPPORTED_FORMATS = ("csv", "json", "excel")
MAXIMUM_FILE_SIZE_MB = 200 

@app.command()
def convert(
    input_file: Path = typer.Option(..., "--input", "-i", exists=False, help="Input file path"),
    output_file: Path = typer.Option(..., "--output", "-o", help="Output file path"),
    output_format: str = typer.Option(..., "--format", "-f", help="csv | json | excel"),
    drop_duplicates: bool = typer.Option(False, "--drop-duplicates", help="Remove duplicate rows"),
    drop_empty: bool = typer.Option(False, "--drop-empty", help="Remove fully empty rows/columns"),
    trim_whitespace: bool = typer.Option(False, "--trim-whitespace", help="Trim whitespace from text fields"),
    standardize_dates: bool = typer.Option(False, "--standardize-dates", help="Normalize date columns"),
    recipe: Optional[Path] = typer.Option(None, "--recipe", help="Path to a JSON/YAML cleaning recipe"),
    show_summary: bool = typer.Option(False, "--summary", help="Print profiling summary before saving"),
    encoding: Optional[str] = typer.Option(None, "--encoding", help="Force a specific input encoding"),
):

    if output_format.lower() not in SUPPORTED_FORMATS:
        typer.secho(f"Unsupported output format '{output_format}'. Use one of {SUPPORTED_FORMATS}.", fg="red")
        raise typer.Exit(code=1)

    try:
        if recipe:
            settings = recipes.load_recipe(recipe)
            drop_duplicates = settings.get("drop_duplicates", drop_duplicates)
            drop_empty = settings.get("drop_empty", drop_empty)
            trim_whitespace = settings.get("trim_whitespace", trim_whitespace)
            standardize_dates = settings.get("standardize_dates", standardize_dates)
            typer.secho(f"Loaded recipe: {recipe}", fg="blue")

        # --- Large file advisory (no forced chunking — just a heads-up) ---
        size_mb = input_file.stat().st_size / 1_048_576 if input_file.exists() else 0
        if size_mb > MAXIMUM_FILE_SIZE_MB:
            typer.secho(
                f"⚠ Input is {size_mb:.0f} MB. For files this large, consider using "
                f"`pd.read_csv(chunksize=...)` or splitting the file — full in-memory "
                f"load may be slow on constrained machines.",
                fg="yellow",
            )

        df = core.load_data(input_file, encoding=encoding)

        if show_summary:
            profiling.print_summary(df)

        df = core.clean_pipeline(
            df,
            drop_duplicates=drop_duplicates,
            drop_empty=drop_empty,
            trim_whitespace_flag=trim_whitespace,
            standardize_dates_flag=standardize_dates,
        )

        core.save_data(df, output_file, output_format)
        typer.secho(f"✔ File converted and saved to {output_file}", fg="green")

    except FileNotFoundError as e:
        typer.secho(f"✘ {e}", fg="red")
        raise typer.Exit(code=1)
    except core.UnsupportedFormatError as e:
        typer.secho(f"✘ {e}", fg="red")
        raise typer.Exit(code=1)
    except Exception as e:
        typer.secho(f"✘ Unexpected error: {e}", fg="red")
        raise typer.Exit(code=1)


@app.command()
def profile(
    input_file: Path = typer.Option(..., "--input", "-i", help="File to profile"),
    encoding: Optional[str] = typer.Option(None, "--encoding", help="Force a specific input encoding"),
):
    try:
        df = core.load_data(input_file, encoding=encoding)
        profiling.print_summary(df)
    except Exception as e:
        typer.secho(f"✘ {e}", fg="red")
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()