import pandas as pd
from rich.console import Console
from rich.table import Table

console = Console()


def print_summary(df: pd.DataFrame) -> None:
    console.print(f"\n[bold cyan]Dataset Summary[/bold cyan]")
    console.print(f"Rows: {len(df):,}   Columns: {len(df.columns)}")
    console.print(f"Memory usage: {df.memory_usage(deep=True).sum() / 1_048_576:.2f} MB\n")

    table = Table(title="Column Details")
    table.add_column("Column", style="cyan")
    table.add_column("Dtype", style="magenta")
    table.add_column("Missing", style="red")
    table.add_column("Missing %", style="yellow")

    for col in df.columns:
        missing = df[col].isna().sum()
        pct = (missing / len(df) * 100) if len(df) else 0
        table.add_row(col, str(df[col].dtype), str(missing), f"{pct:.1f}%")

    console.print(table)