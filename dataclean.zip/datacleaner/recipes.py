import json
import yaml
from pathlib import Path
from typing import Dict, Any

def load_recipe(recipe_path: Path) -> Dict[str, Any]:
    if not recipe_path.exists():
        raise FileNotFoundError(f"Recipe file not found: {recipe_path}")

    text = recipe_path.read_text(encoding="utf-8")
    if recipe_path.suffix.lower() == ".json":
        return json.loads(text)
    elif recipe_path.suffix.lower() in (".yaml", ".yml"):
        return yaml.safe_load(text)
    else:
        raise ValueError("Recipe must be .json, .yaml, or .yml")